
import java.util.Scanner;

public class Calculator {
    private static Scanner sc = new Scanner(System.in);
    private static String row = "=========================================";
    public static void main(String[] arguments){
        System.out.println(row);
        Algebraic first = getAlg("Enter Vector or Matrix");
        String text = first instanceof Matrix ? "Determinant" : "Cross Product";
        boolean isCont = true;
        while(isCont){
            System.out.printf("Select an operation: %n" + 
                                "1: Negate %n" + 
                                "2: Add %n" + 
                                "3: Subtract %n" + 
                                "4: Multiply %n" + 
                                "5: %s %n" + 
                                "6: Compare %n" + 
                                "7: Exit %n" + 
                                "Enter your choice: ", text);
            String oper = sc.next().trim();
            sc.nextLine();
            //I check 7 first to enhance the performance
            if(oper.equals("7")){
                isCont = false;
                System.out.println("Exiting...");
            }
            
            else if(oper.equals("1")){
                System.out.println("-" + first + " = " + first.negate());
            }
            
            else if(oper.equals("2")){
                Algebraic second = getAlg("Enter the second vector or matrix:");
                Algebraic result = first.add(second);
                if(result == null){
                    System.err.println("Invalid operation...");
                }else{
                    System.out.print(first + " + " + second + " = " + result);
                }
            }
            
            else if(oper.equals("3")){
                Algebraic second = getAlg("Enter the second vector or matrix:");
                Algebraic result = first.subtract(second);
                if(result == null){
                    System.err.println("Invalid operation...");
                }else{
                    System.out.print(first + " - " + second + " = " + result);
                }
            }
            
            else if(oper.equals("4")){
                Algebraic second = getAlg("Enter the second vector or matrix:");
                Algebraic result = first.multiply(second);
                if(result == null){
                    System.err.println("Invalid operation...");
                }else{
                    System.out.print(first + " * " + second + " = " + result);
                }
            }
            
            else if(oper.equals("6")){
                Algebraic second = getAlg("Enter the second vector or matrix:");
                boolean result = first.equals(second);
                System.out.println(first + " == " + second + " ==> " + result);
            }
            
            else if(oper.equals("5") && first instanceof Matrix){
                System.out.println(((Matrix)first).determinant());
            }
            
            else if(oper.equals("5") && first instanceof Vector){
                Algebraic second = getAlg("Enter the second vector or matrix:");
                if(second instanceof Vector){
                    Vector ans = ((Vector)first).crossproduct((Vector)second);
                    if(ans == null){
                        System.out.println("Invalid operation...");
                    }
                    else{
                        System.out.print(first + " x " + second + " = " + ans);
                    }
                }else{
                    System.out.println("Invalid operation...");
                }        
            }
            
            else{
                System.out.println("Invalid operation... Choose another one");
            }
            System.out.println();
        }
    }

    public static Vector getVec(int dim2){
        System.out.print("Enter the elements of the vector seperated by spaces: ");
            float[] data = new float[dim2];
            for(int i = 0; i < dim2 && sc.hasNextFloat(); i++){
                data[i] = sc.nextFloat();
            }
            Vector v = new Vector(data);
            System.out.println(v);
            System.out.println(row);
            return v;
    }

    public static Matrix getMat(int dim1, int dim2){
        System.out.print("Enter the elements of the matrix seperated by spaces: ");
            float[][] data = new float[dim1][dim2];
            for(int i = 0; i < dim2 * dim1 && sc.hasNextFloat(); i++){
                data[i/dim2][i % dim2] = sc.nextFloat();
            }
            Matrix mat = new Matrix(data);
            System.out.println(mat);
            System.out.println(row);
            return mat;
    }

    public static Algebraic getAlg(String prompt){
        System.out.println(prompt);
        Algebraic alg = null;
        System.out.print("Enter number of rows and columns (n x m): ");
        int dim1 = 0, dim2 = 0;

        dim1 = sc.nextInt();
        dim2 = sc.nextInt();
        sc.nextLine();

        if(dim1 == 1){
            alg = getVec(dim2);
        }else{
            alg = getMat(dim1, dim2);
        }

        return alg;
    }
}